
<?php $__env->startSection("content"); ?>
<style>
    /* body {
        font-family: Arial, sans-serif;
        background-color: #f5f5f5;
        margin: 0;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    #chat-container {
        background-color: #fff;
        border: 1px solid #ddd;
        border-radius: 10px;
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); 
    }

    #message-input {
        display: flex;
        padding: 15px;
        border-top: 1px solid #ddd;
        box-sizing: border-box;
        align-items: center;
    }

    #message-input input {
        flex-grow: 1;
        padding: 15px;
        border: 1px solid #ddd;
        border-radius: 20px;
        margin-right: 10px;
        font-size: 16px;
        box-sizing: border-box;
    }

    #message-input button {
        padding: 15px 20px;
        border: none;
        background-color: #007bff;
        color: white;
        border-radius: 20px;
        cursor: pointer;
        font-size: 16px;
        transition: background-color 0.3s;
    }

    #message-input button:hover {
        background-color: #0056b3;
    }

    #messages {
        flex: 1;
        padding: 15px;
        overflow-y: auto;
        display: flex;
        flex-direction: column-reverse;
        box-sizing: border-box;
        background-color: #fafafa;
    }

    .message {
        display: flex;
        margin-bottom: 15px;
        align-items: flex-end;
        max-width: 70%;
    }

    .message.user {
        justify-content: flex-start;
    }

    .message.admin {
        justify-content: flex-end;
        align-self: flex-end;
    }

    .message-content {
        padding: 15px;
        border-radius: 20px;
        position: relative;
        font-size: 16px;
        box-sizing: border-box;
        word-break: break-word;
    }

    .message.user .message-content {
        background-color: #f1f0f0;
        border-bottom-left-radius: 0;
    }

    .message.admin .message-content {
        background-color: #e1f7d5;
        border-bottom-right-radius: 0;
    }

    .timestamp {
        font-size: 0.8em;
        color: #888;
        margin-top: 5px;
        text-align: right;
    } */
</style>
<link rel="stylesheet" href="<?php echo e(asset("../resources/css/chatDetail.css")); ?>">
<body>
    <div id="chat-container">
        <div id="messages">
            <ul id="messageList" style="list-style-type:none; padding:0; margin:0;"></ul>
        </div>
        <div id="message-input">
            <input type="text" id="chat" placeholder="Type your message">
            <button id="btn_send">Send</button>
        </div>
    </div>

    <script src="https://chatrealtime-n1cn.onrender.com/socket.io/socket.io.js"></script>
    <script>
        const currentURL = window.location.href;
        const urlParts = currentURL.split('/');
        const id = parseInt(urlParts[urlParts.length - 1]);

        const socket = io("https://chatrealtime-n1cn.onrender.com");

        const btn_send = document.getElementById('btn_send');
        const room_id = document.getElementById('room_id');
        const chat = document.getElementById('chat');
        const messageList = document.getElementById('messageList');

        // Join the room
        socket.emit("join", id);
        console.log(`Joined room ${id}`);

        // Send message
        btn_send.addEventListener('click', () => {
            const message = {
                id: -1,
                receiver_id: room_id ? room_id.value : '',
                content: chat.value,
                sender_id: localStorage.getItem('userID'),
                room_id: room_id ? room_id.value : '',
                role: 'admin',
                updated_time: "",
                created_time: getCurrentFormattedTime()
            };
            socket.emit("message", JSON.stringify(message));
            chat.value = '';
            console.log(`Message sent: ${JSON.stringify(message)}`);
        });

        socket.on("thread", function (data) {
            const parsedMessage = JSON.parse(data);
            displayMessage(parsedMessage);
            console.log(`Received message: ${JSON.stringify(data)}`);
        });

        socket.on("history", function (data) {
            document.getElementById('messageList').innerHTML = "";
            // const messages = JSON.parse(JSON.stringify(data));
            const fakeData = [
        { id: 1, content: "Hello", role: "admin", created_time: getCurrentFormattedTime() },
        { id: 2, content: "Hi there", role: "customer", created_time: getCurrentFormattedTime() }
        // Thêm các tin nhắn giả mạo khác tương tự ở đây nếu cần
    ];

    const messages = JSON.parse(JSON.stringify(fakeData));
            messages.forEach(message => {
                displayMessage(message);
            });
            console.log(`Chat history: ${JSON.stringify(data)}`);
        });

        function displayMessage(message) {
            const messageElement = document.createElement('li');
            messageElement.classList.add('message');
            messageElement.classList.add(message.role === 'admin' ? 'admin' : 'customer');
            messageElement.innerHTML = `
                <div class="message-content">
                    <span>${message.content}</span>
                    <div class="timestamp">${message.created_time}</div>
                </div>
            `;
            messageList.appendChild(messageElement);
        }

        function getCurrentFormattedTime() {
            const now = new Date();
            const year = now.getFullYear();
            const month = String(now.getMonth() + 1).padStart(2, '0');
            const day = String(now.getDate()).padStart(2, '0');
            const hours = String(now.getHours()).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            const seconds = String(now.getSeconds()).padStart(2, '0');
            return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        }
    </script>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\Xampp\htdocs\admin_food\resources\views/Chat/index.blade.php ENDPATH**/ ?>