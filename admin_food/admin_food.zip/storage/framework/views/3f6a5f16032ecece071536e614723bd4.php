
<?php $__env->startSection("content"); ?>
<a href="<?php echo e(route("category.create")); ?>" class="button green">Thêm món ăn</a>
<table>
    <thead>
        <tr>
            <th>Id</th>
            <th>Tên</th>
            <th>Hình ảnh</th>
            <th>Tên danh mục</th>
            <th>Mô tả</th>
            <th>Nguyên liệu</th>
            <th>Calo</th>
            <th>Số lượng</th>
            <th>Đơn giá</th>
            <th>% Giảm giá</th>
            <th>Thời gian cập nhật</th>
            <th>Hành động</th>
        </tr>
    </thead>
    <tbody id="itemList"></tbody>

<script>
  const BASE_URL = "http://localhost/api_food/public/api/";
  const BASE_URL_IMAGE = "http://localhost/api_food/storage/app/public/images/";

    document.addEventListener("DOMContentLoaded", function() {
        fetch(BASE_URL + 'product')
            .then(response => response.json())
            .then(data => displayItems(data))
            .catch(error => console.error('Error:', error));
    });

    function displayItems(items) {
    const itemList = document.getElementById('itemList');

    items.forEach(item => {
        const row = document.createElement('tr');

        // Thêm các cột dữ liệu
        addCell(row, item.id, 'ID');
        addCell(row, item.name, 'Tên');
        addImageCell(row, BASE_URL_IMAGE + item.image[0].imgurl, 'Hình ảnh');
        addCategoriesCell(row, item.categorie, 'Tên danh mục');
        addCell(row, item.description, 'Mô tả');
        addCell(row, item.ingredient, 'Nguyên liệu');
        addCell(row, item.calo, 'Calo');
        addCell(row, item.quantity, 'Số lượng');
        addCell(row, item.price, 'Đơn giá');
        addCell(row, item.discount, '% Giảm giá');
        addCell(row, item.updated_time, 'Thời gian cập nhật');

        // Thêm nút xóa và nút xem
        const actionsCell = document.createElement('td');
        actionsCell.classList.add('actions-cell');
        const buttonsDiv = document.createElement('div');
        buttonsDiv.classList.add('buttons', 'right', 'nowrap');

        const viewButton = document.createElement('button');
        viewButton.classList.add('button', 'small', 'green', '--jb-modal');
        viewButton.setAttribute('data-target', 'sample-modal-2');
        viewButton.innerHTML = '<span class="icon"><i class="mdi mdi-eye"></i></span>';
        viewButton.addEventListener('click', function() {
            window.location.href = "<?php echo e(url('product')); ?>/" + item.id;
        });
        buttonsDiv.appendChild(viewButton);

        const deleteButton = document.createElement('button');
        deleteButton.classList.add('button', 'small', 'red', '--jb-modal');
        deleteButton.setAttribute('data-target', 'sample-modal');
        deleteButton.type = 'button';
        deleteButton.innerHTML = '<span class="icon"><i class="mdi mdi-trash-can"></i></span>';
        deleteButton.addEventListener('click', function() {
            if (confirm('Bạn chắc chắn muốn xóa mục này?')) {
                deleteItem(item.id);
            }
        });
        buttonsDiv.appendChild(deleteButton);

        actionsCell.appendChild(buttonsDiv);
        row.appendChild(actionsCell);

        itemList.appendChild(row);
    });
}

function addCell(row, data, label) {
    const cell = document.createElement('td');
    cell.textContent = data;
    cell.setAttribute('data-label', label);
    row.appendChild(cell);
}

function addImageCell(row, imageUrl, label) {
    const cell = document.createElement('td');
    const image = document.createElement('img');
    image.src = imageUrl;
    image.style.maxWidth = '100px';
    image.style.height = 'auto';
    cell.appendChild(image);
    cell.setAttribute('data-label', label);
    row.appendChild(cell);
}
function addCategoriesCell(row, categorie, label) {
        const cell = document.createElement('td');
        const categoryNames = categorie.map(category => category.name).join(', '); // Lấy tên của mỗi danh mục và nối chúng thành một chuỗi
        cell.textContent = categoryNames;
        cell.setAttribute('data-label', label);
        row.appendChild(cell);
    }

    function deleteItem(itemId) {
        console.log('Delete item with ID:', itemId);
        fetch(BASE_URL + `items/${itemId}`, {
            method: 'DELETE'
        })
        .then(response => {
            if (response.ok) {
                alert('Xóa mục thành công!');
                window.location.reload(); // Tải lại trang sau khi xóa thành công
            } else {
                alert('Xóa mục thất bại!');
            }
        })
        .catch(error => console.error('Error:', error));
    }
</script>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\Xampp\htdocs\admin_food\resources\views/Product/index.blade.php ENDPATH**/ ?>